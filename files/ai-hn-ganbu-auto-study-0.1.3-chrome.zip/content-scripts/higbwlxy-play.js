var higbwlxyPlay=(function(){"use strict";function re(t){return t}function R(t){const u=window,l="/api/page/courseProcess/singleProcess",r={mode:t.mode,intervalMs:s(t.intervalMs,250,1e4,500),endOffsetSeconds:s(t.endOffsetSeconds,.1,30,.5),playbackRate:s(t.playbackRate,1,16,16),muted:!!t.muted,dispatchEnded:!!t.dispatchEnded,clickNext:!!t.clickNext};if(r.mode==="status")return c();if(r.mode==="stop")return C(),x(),a(),{ok:!0,action:"stopped",message:"\u5DF2\u505C\u6B62\u5F53\u524D\u9875\u9762\u7684\u5FEB\u8FDB\u5B9A\u65F6\u5668\uFF0C\u5E76\u6062\u590D\u540E\u7EED timeupdate \u76D1\u542C\u6CE8\u518C\u903B\u8F91\u3002",pageUrl:location.href,completed:!!u.__hnGanbuVideoFastForwardCompletion?.completed,completionReason:u.__hnGanbuVideoFastForwardCompletion?.reason,video:d(document.querySelector("video"))};a(),u.__hnGanbuVideoFastForwardCompletion={completed:!1,reason:"",updatedAt:Date.now()};const m=document.querySelector("video");if(!(m instanceof HTMLVideoElement))return{ok:!1,action:"failed",message:"\u5F53\u524D\u9875\u9762\u672A\u627E\u5230 HTML5 video \u5143\u7D20\uFF0C\u8BF7\u5148\u8FDB\u5165\u89C6\u9891\u64AD\u653E\u9875\u540E\u518D\u6267\u884C\u3002",pageUrl:location.href};n(),h(),A(m);const p=window.setInterval(()=>{const e=document.querySelector("video");e instanceof HTMLVideoElement&&(A(e),u.__hnGanbuVideoFastForwardState.tickCount+=1)},r.intervalMs);return u.__hnGanbuVideoFastForwardState={timerId:p,startedAt:Date.now(),tickCount:0},{ok:!0,action:"started",message:`\u5DF2\u542F\u52A8\u5FEB\u8FDB\uFF1A\u6BCF ${r.intervalMs}ms \u5C06\u89C6\u9891\u63A8\u8FDB\u5230\u7ED3\u5C3E\u524D ${r.endOffsetSeconds}s\u3002`,pageUrl:location.href,completed:!1,video:d(m)};function s(e,i,f,F){return Number.isFinite(e)?Math.min(f,Math.max(i,e)):F}function a(){const e=u.__hnGanbuVideoFastForwardState;e&&(window.clearInterval(e.timerId),delete u.__hnGanbuVideoFastForwardState)}function c(){const e=u.__hnGanbuVideoFastForwardCompletion,i=!!u.__hnGanbuVideoFastForwardState;return{ok:!0,action:"status",message:e?.completed?e.reason:i?"\u5FEB\u8FDB\u6267\u884C\u4E2D":"\u5F53\u524D\u9875\u9762\u672A\u5728\u6267\u884C\u5FEB\u8FDB",pageUrl:location.href,completed:!!e?.completed,completionReason:e?.reason,video:d(document.querySelector("video"))}}function n(){if(u.__hnGanbuVideoFastForwardOriginalAddEventListener)return;const e=EventTarget.prototype.addEventListener;u.__hnGanbuVideoFastForwardOriginalAddEventListener=e,EventTarget.prototype.addEventListener=function(f,F,g){if(f!=="timeupdate"||!F){e.call(this,f,F,g);return}const E=function(w){const v=w.target,b=v instanceof HTMLVideoElement?v:null,H=b?Object.getOwnPropertyDescriptor(b,"currentTime"):void 0;let q=!1;if(b&&Number.isFinite(b.duration)&&b.duration>0)try{Object.defineProperty(b,"currentTime",{configurable:!0,get:()=>Math.max(0,b.duration-r.endOffsetSeconds)}),q=!0}catch{}try{if(typeof F=="function"){F.call(this,w);return}F.handleEvent(w)}finally{if(b&&q)try{H?Object.defineProperty(b,"currentTime",H):delete b.currentTime}catch{}}};e.call(this,f,E,g)}}function C(){const e=u.__hnGanbuVideoFastForwardOriginalAddEventListener;e&&(EventTarget.prototype.addEventListener=e,delete u.__hnGanbuVideoFastForwardOriginalAddEventListener)}function h(){if(u.__hnGanbuVideoFastForwardNetworkPatch)return;const e=window.fetch?.bind(window),i=XMLHttpRequest.prototype.open,f=XMLHttpRequest.prototype.send;u.__hnGanbuVideoFastForwardNetworkPatch={originalFetch:window.fetch,originalXhrOpen:i,originalXhrSend:f},e&&(window.fetch=function(g,E){const y=I(g,E);return e(g,E).then(w=>(D(y.url,y.method)&&w.clone().json().then(v=>_(v)).catch(()=>{}),w))}),XMLHttpRequest.prototype.open=function(g,E,y,w,v){this.__hnGanbuProgressRequest={method:String(g||"GET").toUpperCase(),url:String(E)},i.call(this,g,E,y??!0,w??null,v??null)},XMLHttpRequest.prototype.send=function(g){const E=this.__hnGanbuProgressRequest;E&&D(E.url,E.method)&&this.addEventListener("load",()=>{try{const y=typeof this.response=="string"||!this.response?JSON.parse(this.responseText):this.response;_(y)}catch{}}),f.call(this,g)}}function I(e,i){return e instanceof Request?{method:String(i?.method||e.method||"GET").toUpperCase(),url:e.url}:{method:String(i?.method||"GET").toUpperCase(),url:String(e)}}function D(e,i){return i.toUpperCase()==="POST"&&B(e).includes(l)}function B(e){try{return new URL(e,location.href).href}catch{return e}}function _(e){P(e)&&(u.__hnGanbuVideoFastForwardCompletion={completed:!0,reason:"\u68C0\u6D4B\u5230\u5B66\u4E60\u8FDB\u5EA6\u63A5\u53E3\u8FD4\u56DE\u6210\u529F\uFF0C\u8FDB\u5EA6\u5DF2\u8FBE\u5230 100%",updatedAt:Date.now()},a(),C(),x(),window.dispatchEvent(new CustomEvent("hn-ganbu-fast-forward-completed")))}function P(e){if(!e||typeof e!="object")return!1;const i=e;return Number(i.code)===0&&i.msg==="ok"&&i.data?.content==="\u8BB0\u5F55\u6210\u529F"&&Number(i.data?.browseScore)>=100}function x(){const e=u.__hnGanbuVideoFastForwardNetworkPatch;e&&(e.originalFetch&&(window.fetch=e.originalFetch),XMLHttpRequest.prototype.open=e.originalXhrOpen,XMLHttpRequest.prototype.send=e.originalXhrSend,delete u.__hnGanbuVideoFastForwardNetworkPatch)}function A(e){r.muted&&(e.muted=!0);try{e.playbackRate=r.playbackRate}catch{}N(e),e.play().catch(()=>{}),r.dispatchEnded&&(e.dispatchEvent(new Event("timeupdate",{bubbles:!0})),e.dispatchEvent(new Event("ended",{bubbles:!0}))),r.clickNext&&S()}function N(e){if(!Number.isFinite(e.duration)||e.duration<=0)return;const i=Math.max(0,e.duration-r.endOffsetSeconds);try{e.currentTime=i}catch{}}function S(){const e=[".next-episode",".next-btn",'[class*="next"]','[class*="Next"]','button[aria-label*="\u4E0B\u4E00"]','a[aria-label*="\u4E0B\u4E00"]','button[title*="\u4E0B\u4E00"]','a[title*="\u4E0B\u4E00"]'];for(const F of e){const g=document.querySelector(F);if(g instanceof HTMLElement&&o(g))return g.click(),!0}const f=Array.from(document.querySelectorAll('button, a, [role="button"]')).find(F=>{const g=`${F.textContent??""} ${F.getAttribute("aria-label")??""}`;return/下一|下一个|下一节|下一集/.test(g)&&o(F)});return f?(f.click(),!0):!1}function o(e){const i=window.getComputedStyle(e);return!(e.getAttribute("aria-disabled")==="true"||e.hasAttribute("disabled")||i.pointerEvents==="none")&&i.display!=="none"&&i.visibility!=="hidden"}function d(e){if(e instanceof HTMLVideoElement)return{duration:Number.isFinite(e.duration)?Number(e.duration.toFixed(2)):null,currentTime:Number.isFinite(e.currentTime)?Number(e.currentTime.toFixed(2)):null,playbackRate:Number.isFinite(e.playbackRate)?e.playbackRate:null}}}const U={key_ops:["verify"],ext:!0,kty:"EC",x:"_layTSNVNOl41aJZulJQ5ngqlCDaYdVk3_BHMsA3gXc",y:"DL0OK9h76YRnIsC3gcPIdpxVkexYHCZuQy5VRFRDdZM",crv:"P-256"},$="hnGanbuRedeemCode",L="HNGB.v1";let M=null;async function X(t,u,l=new Date){const r=V(u);if(!r||r==="-")return{ok:!1,status:"missing-user",message:"\u8BF7\u5148\u767B\u5F55\u6D77\u5357\u5E72\u90E8\u7F51\u7EDC\u5B66\u9662\uFF0C\u518D\u6267\u884C\u5FEB\u8FDB\u3002"};const m=t.trim();if(!m)return{ok:!1,status:"missing-code",message:`\u8BF7\u5C06\u7528\u6237 ID\uFF1A${r} \u53D1\u7ED9\u5546\u5BB6\u8D2D\u4E70\u5151\u6362\u7801\u3002`};const p=j(m);if(!p.ok)return p;if(!await Y(p.signingText,p.signature))return{ok:!1,status:"invalid-signature",message:"\u5151\u6362\u7801\u7B7E\u540D\u65E0\u6548\uFF0C\u8BF7\u786E\u8BA4\u5151\u6362\u7801\u662F\u5426\u5B8C\u6574\u3002"};const a=p.payload;if(V(a.userId)!==r)return{ok:!1,status:"user-mismatch",message:"\u5151\u6362\u7801\u4E0E\u5F53\u524D\u8D26\u53F7\u4E0D\u5339\u914D\uFF0C\u8BF7\u91CD\u65B0\u8D2D\u4E70\u5151\u6362\u7801\u3002",payload:a};const c=J(a.createdAt),n=W(a.expiresAt);return!c||!n||c.getTime()>n.getTime()?{ok:!1,status:"invalid-payload",message:"\u5151\u6362\u7801\u65E5\u671F\u65E0\u6548\uFF0C\u8BF7\u8054\u7CFB\u5546\u5BB6\u91CD\u65B0\u751F\u6210\u3002",payload:a}:l.getTime()<c.getTime()?{ok:!1,status:"not-started",message:`\u5151\u6362\u7801\u5C1A\u672A\u751F\u6548\uFF0C\u751F\u6548\u65E5\u671F\u4E3A ${a.createdAt}\u3002`,payload:a}:l.getTime()>n.getTime()?{ok:!1,status:"expired",message:`\u5151\u6362\u7801\u5DF2\u4E8E ${a.expiresAt} \u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8D2D\u4E70\u5151\u6362\u7801\u3002`,payload:a}:{ok:!0,status:"valid",message:`\u5151\u6362\u7801\u6709\u6548\u671F\u81F3 ${a.expiresAt}\u3002`,payload:a}}function j(t){const u=t.trim().split(".");if(u.length!==4||`${u[0]}.${u[1]}`!==L)return{ok:!1,status:"invalid-format",message:"\u5151\u6362\u7801\u683C\u5F0F\u4E0D\u6B63\u786E\uFF0C\u8BF7\u7C98\u8D34\u5B8C\u6574\u5151\u6362\u7801\u3002"};const l=u[2],r=u[3];if(!l||!r)return{ok:!1,status:"invalid-format",message:"\u5151\u6362\u7801\u683C\u5F0F\u4E0D\u5B8C\u6574\uFF0C\u8BF7\u7C98\u8D34\u5B8C\u6574\u5151\u6362\u7801\u3002"};try{const m=JSON.parse(Z(l));return z(m)?{ok:!0,payload:m,signature:O(r),signingText:`${L}.${l}`}:{ok:!1,status:"invalid-payload",message:"\u5151\u6362\u7801\u5185\u5BB9\u65E0\u6548\uFF0C\u8BF7\u8054\u7CFB\u5546\u5BB6\u91CD\u65B0\u751F\u6210\u3002"}}catch{return{ok:!1,status:"invalid-format",message:"\u5151\u6362\u7801\u89E3\u6790\u5931\u8D25\uFF0C\u8BF7\u7C98\u8D34\u5B8C\u6574\u5151\u6362\u7801\u3002"}}}function z(t){return t.version===1&&typeof t.userId=="string"&&t.userId.trim().length>0&&T(t.createdAt)&&T(t.expiresAt)&&typeof t.nonce=="string"&&t.nonce.trim().length>=8}function V(t){return t.trim()}async function Y(t,u){try{const l=await K(),r=u.buffer.slice(u.byteOffset,u.byteOffset+u.byteLength);return await crypto.subtle.verify({name:"ECDSA",hash:"SHA-256"},l,r,new TextEncoder().encode(t))}catch{return!1}}function K(){return M??=crypto.subtle.importKey("jwk",U,{name:"ECDSA",namedCurve:"P-256"},!1,["verify"]),M}function T(t){return typeof t=="string"&&/^\d{4}-\d{2}-\d{2}$/.test(t)}function J(t){if(!T(t))return null;const u=new Date(`${t}T00:00:00`);return Number.isNaN(u.getTime())?null:u}function W(t){if(!T(t))return null;const u=new Date(`${t}T23:59:59.999`);return Number.isNaN(u.getTime())?null:u}function Z(t){return new TextDecoder().decode(O(t))}function O(t){const u=t.replace(/-/g,"+").replace(/_/g,"/"),l=u.padEnd(Math.ceil(u.length/4)*4,"="),r=atob(l),m=new Uint8Array(r.length);for(let p=0;p<r.length;p+=1)m[p]=r.charCodeAt(p);return m}function Q(){function t(s){const a=document.cookie.split(";");for(const c of a){const n=c.indexOf("=");if(n<0)continue;const C=c.slice(0,n).trim(),h=c.slice(n+1).trim();if(l(C)===s)return l(h)}return""}function u(s){const a=s.replace(/-/g,"+").replace(/_/g,"/"),c=a.padEnd(Math.ceil(a.length/4)*4,"="),n=atob(c),C=Uint8Array.from(n,h=>h.charCodeAt(0));return new TextDecoder().decode(C)}function l(s){try{return decodeURIComponent(s)}catch{return s}}const r=t("token");if(!r)return{ok:!1,message:"\u672A\u5728\u5F53\u524D\u9875\u9762 cookie \u4E2D\u8BFB\u53D6\u5230 token"};const p=r.replace(/^Bearer\s*/i,"").trim().split(".");if(p.length<2)return{ok:!1,message:"token \u683C\u5F0F\u4E0D\u7B26\u5408 JWT \u7ED3\u6784"};try{const s=JSON.parse(u(p[1])),a=s.userid??s.id,c=s.name,n=s.username;return a===void 0&&c===void 0&&n===void 0?{ok:!1,message:"token payload \u4E2D\u672A\u627E\u5230\u7528\u6237\u5B57\u6BB5"}:{ok:!0,message:"\u5DF2\u8BFB\u53D6\u5F53\u524D\u767B\u5F55\u7528\u6237",user:{id:a==null?"-":String(a),name:typeof c=="string"&&c?c:"-",username:typeof n=="string"&&n?n:"-"}}}catch{return{ok:!1,message:"token payload \u89E3\u6790\u5931\u8D25"}}}const ee="https://www.higbwlxy.gov.cn/#/play",G=5e3,te=250,ue="hn-ganbu-open-redeem-popup",ne={matches:["https://www.higbwlxy.gov.cn/*"],runAt:"document_idle",world:"MAIN",main(){const t=window;t.__hnGanbuPlayFastForwardButton?.cleanup?.();const u=document.createElement("div");u.id="hn-ganbu-fast-forward-root",u.style.position="fixed",u.style.right="20px",u.style.bottom="96px",u.style.zIndex="2147483647",u.style.display="none";const l=u.attachShadow({mode:"open"});l.innerHTML=`
      <style>
        :host {
          all: initial;
          font-family: "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Segoe UI", Arial, sans-serif;
        }

        .panel {
          display: grid;
          gap: 8px;
          min-width: 156px;
          padding: 10px;
          border: 1px solid rgba(35, 118, 211, 0.28);
          border-radius: 10px;
          background: rgba(255, 255, 255, 0.96);
          box-shadow: 0 10px 28px rgba(17, 24, 39, 0.18);
          backdrop-filter: blur(8px);
        }

        button {
          min-height: 38px;
          padding: 0 14px;
          border: 0;
          border-radius: 8px;
          color: #fff;
          background: #2376d3;
          font: 700 14px/1.2 "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Segoe UI", Arial, sans-serif;
          cursor: pointer;
          transition: background-color 160ms ease, transform 160ms ease, opacity 160ms ease;
        }

        button:hover:not(:disabled) {
          background: #1b63b4;
        }

        button:active:not(:disabled) {
          transform: translateY(1px);
        }

        button:disabled {
          cursor: wait;
          opacity: 0.72;
        }

        button:focus-visible {
          outline: 2px solid #8bbcf0;
          outline-offset: 2px;
        }

        .assist-row {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 8px;
          align-items: center;
        }

        .status {
          margin: 0;
          color: #40506a;
          font: 12px/1.45 "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Segoe UI", Arial, sans-serif;
          overflow-wrap: anywhere;
        }

        .redeem-button {
          display: none;
          min-height: 28px;
          padding: 0 10px;
          border: 1px solid #b8c7da;
          color: #2376d3;
          background: #fff;
          font-size: 12px;
          white-space: nowrap;
        }

        .redeem-button:hover:not(:disabled) {
          background: #edf5ff;
        }

        .redeem-button.is-visible {
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        @media (prefers-reduced-motion: reduce) {
          button {
            transition: none;
          }
        }
      </style>
      <div class="panel">
        <button type="button">\u6267\u884C\u5FEB\u8FDB</button>
        <div class="assist-row">
          <p class="status">\u70B9\u51FB\u540E\u5148\u6821\u9A8C\u5151\u6362\u7801\uFF0C\u518D\u8FD0\u884C 5 \u79D2\u81EA\u52A8\u505C\u6B62</p>
          <button class="redeem-button" type="button">\u586B\u5199\u5151\u6362\u7801</button>
        </div>
      </div>
    `;const r=l.querySelector("button"),m=l.querySelector(".redeem-button"),p=l.querySelector(".status");if(!(r instanceof HTMLButtonElement)||!(m instanceof HTMLButtonElement)||!(p instanceof HTMLParagraphElement))return;const s=r,a=m,c=p;document.documentElement.append(u);const n={root:u,completionCheckTimerId:void 0,countdownTimerId:void 0,stopTimerId:void 0,syncTimerId:void 0,cleanup:void 0};t.__hnGanbuPlayFastForwardButton=n,s.addEventListener("click",()=>{C()}),a.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent(ue))});async function C(){if(n.stopTimerId)return;s.disabled=!0,s.textContent="\u6821\u9A8C\u4E2D",c.textContent="\u6B63\u5728\u6821\u9A8C\u767B\u5F55\u72B6\u6001\u4E0E\u5151\u6362\u7801";const o=await I();if(!o.ok){s.disabled=!1,s.textContent="\u6267\u884C\u5FEB\u8FDB",c.textContent=o.message,D(o.needsRedeemCode);return}D(!1);const d=R(S("run"));if(!d.ok){s.disabled=!1,s.textContent="\u6267\u884C\u5FEB\u8FDB",c.textContent=d.message;return}let e=G/1e3;s.disabled=!0,s.textContent=`\u6267\u884C\u4E2D ${e}s`,c.textContent="\u6B63\u5728\u63A8\u8FDB\u89C6\u9891\u8FDB\u5EA6\uFF0C\u7A0D\u540E\u81EA\u52A8\u505C\u6B62",n.countdownTimerId=window.setInterval(()=>{e-=1,s.textContent=`\u6267\u884C\u4E2D ${Math.max(e,0)}s`},1e3),n.completionCheckTimerId=window.setInterval(()=>{const i=t.__hnGanbuVideoFastForwardCompletion;if(i?.completed){B(i.reason||"\u68C0\u6D4B\u5230\u63A5\u53E3\u8FD4\u56DE\u8FDB\u5EA6 100%\uFF0C\u5DF2\u505C\u6B62");return}_()&&B("\u68C0\u6D4B\u5230\u9875\u9762\u8FDB\u5EA6\u5DF2\u5B8C\u6210\uFF0C\u5DF2\u505C\u6B62")},te),n.stopTimerId=window.setTimeout(()=>{B("\u5DF2\u81EA\u52A8\u505C\u6B62\uFF0C\u53EF\u518D\u6B21\u6267\u884C")},G)}const h=()=>{const o=location.href.startsWith(ee);u.style.display=o?"block":"none",o||B("\u70B9\u51FB\u540E\u5148\u6821\u9A8C\u5151\u6362\u7801\uFF0C\u518D\u8FD0\u884C 5 \u79D2\u81EA\u52A8\u505C\u6B62")};h(),window.addEventListener("hashchange",h),window.addEventListener("popstate",h),n.syncTimerId=window.setInterval(h,1e3),n.cleanup=()=>{window.removeEventListener("hashchange",h),window.removeEventListener("popstate",h),n.syncTimerId&&window.clearInterval(n.syncTimerId),B("\u70B9\u51FB\u540E\u5148\u6821\u9A8C\u5151\u6362\u7801\uFF0C\u518D\u8FD0\u884C 5 \u79D2\u81EA\u52A8\u505C\u6B62"),u.remove()};async function I(){const o=Q();if(!o.user)return{ok:!1,message:"\u8BF7\u5148\u767B\u5F55\u6D77\u5357\u5E72\u90E8\u7F51\u7EDC\u5B66\u9662\uFF0C\u518D\u6267\u884C\u5FEB\u8FDB\u3002",needsRedeemCode:!1};const d=window.localStorage.getItem($)??"",e=await X(d,o.user.id);return{ok:e.ok,message:e.message,needsRedeemCode:!e.ok}}function D(o){a.classList.toggle("is-visible",o)}function B(o){n.completionCheckTimerId&&(window.clearInterval(n.completionCheckTimerId),n.completionCheckTimerId=void 0),n.countdownTimerId&&(window.clearInterval(n.countdownTimerId),n.countdownTimerId=void 0),n.stopTimerId&&(window.clearTimeout(n.stopTimerId),n.stopTimerId=void 0,R(S("stop"))),s.disabled=!1,s.textContent="\u6267\u884C\u5FEB\u8FDB",c.textContent=o,D(!1)}function _(){const o=document.querySelector("video");if(o instanceof HTMLVideoElement&&o.ended)return!0;const d=document.querySelector("progress");if(d instanceof HTMLProgressElement){const f=d.max||1;if(f>0&&d.value/f>=.999)return!0}const e=Array.from(document.querySelectorAll(["[aria-valuenow]","[aria-valuetext]",'[class*="progress"]','[class*="Progress"]','[class*="percent"]','[class*="Percent"]','[class*="complete"]','[class*="Complete"]','[class*="finish"]','[class*="Finish"]','[class*="status"]','[class*="Status"]'].join(","))).filter(f=>N(f));for(const f of e)if(P(f)||x(f.textContent??""))return!0;const i=A(document.body?.innerText??"");return/学习完成|播放完成|课程完成|完成学习|获得学时|(?:学习|播放|课程|进度).{0,8}(?:已完成|100%)|100%\s*(?:已完成|完成|学习|进度)/.test(i)}function P(o){const d=Number.parseFloat(o.getAttribute("aria-valuenow")??""),e=Number.parseFloat(o.getAttribute("aria-valuemax")??"100");return Number.isFinite(d)&&d>=100?!0:Number.isFinite(d)&&Number.isFinite(e)&&e>0?d/e>=.999:x(o.getAttribute("aria-valuetext")??"")}function x(o){const d=A(o);return!d||/未完成|未学完|未播放完成/.test(d)?!1:/100%|已完成|学习完成|播放完成|课程完成|完成学习|获得学时/.test(d)}function A(o){return o.replace(/\s+/g," ").trim()}function N(o){const d=window.getComputedStyle(o),e=o.getBoundingClientRect();return d.display!=="none"&&d.visibility!=="hidden"&&e.width>0&&e.height>0}function S(o){return{mode:o,intervalMs:500,endOffsetSeconds:.5,playbackRate:16,muted:!0,dispatchEnded:!0,clickNext:!0}}}};function se(){}function k(t,...u){}const oe={debug:(...t)=>k(console.debug,...t),log:(...t)=>k(console.log,...t),warn:(...t)=>k(console.warn,...t),error:(...t)=>k(console.error,...t)};return(async()=>{try{return await ne.main()}catch(t){throw oe.error('The content script "higbwlxy-play" crashed on startup!',t),t}})()})();

higbwlxyPlay;