var higbwlxyPlay=(function(){"use strict";function re(t){return t}function R(t){const u=window,c="/api/page/courseProcess/singleProcess",s={mode:t.mode,intervalMs:l(t.intervalMs,250,1e4,500),endOffsetSeconds:l(t.endOffsetSeconds,.1,30,.5),playbackRate:l(t.playbackRate,1,16,16),muted:!!t.muted,dispatchEnded:!!t.dispatchEnded,clickNext:!!t.clickNext};if(s.mode==="status")return p();if(s.mode==="stop")return h(),_(),r(),{ok:!0,action:"stopped",message:"\u5DF2\u505C\u6B62\u5F53\u524D\u9875\u9762\u7684\u5FEB\u8FDB\u5B9A\u65F6\u5668\uFF0C\u5E76\u6062\u590D\u540E\u7EED timeupdate \u76D1\u542C\u6CE8\u518C\u903B\u8F91\u3002",pageUrl:location.href,completed:!!u.__hnGanbuVideoFastForwardCompletion?.completed,completionReason:u.__hnGanbuVideoFastForwardCompletion?.reason,video:D(document.querySelector("video"))};r(),u.__hnGanbuVideoFastForwardCompletion={completed:!1,reason:"",updatedAt:Date.now()};const F=document.querySelector("video");if(!(F instanceof HTMLVideoElement))return{ok:!1,action:"failed",message:"\u5F53\u524D\u9875\u9762\u672A\u627E\u5230 HTML5 video \u5143\u7D20\uFF0C\u8BF7\u5148\u8FDB\u5165\u89C6\u9891\u64AD\u653E\u9875\u540E\u518D\u6267\u884C\u3002",pageUrl:location.href};f(),E(),I(F);const m=window.setInterval(()=>{const e=document.querySelector("video");e instanceof HTMLVideoElement&&(I(e),u.__hnGanbuVideoFastForwardState.tickCount+=1)},s.intervalMs);return u.__hnGanbuVideoFastForwardState={timerId:m,startedAt:Date.now(),tickCount:0},{ok:!0,action:"started",message:`\u5DF2\u542F\u52A8\u5FEB\u8FDB\uFF1A\u6BCF ${s.intervalMs}ms \u5C06\u89C6\u9891\u63A8\u8FDB\u5230\u7ED3\u5C3E\u524D ${s.endOffsetSeconds}s\u3002`,pageUrl:location.href,completed:!1,video:D(F)};function l(e,a,b,n){return Number.isFinite(e)?Math.min(b,Math.max(a,e)):n}function r(){const e=u.__hnGanbuVideoFastForwardState;e&&(window.clearInterval(e.timerId),delete u.__hnGanbuVideoFastForwardState)}function p(){const e=u.__hnGanbuVideoFastForwardCompletion,a=!!u.__hnGanbuVideoFastForwardState;return{ok:!0,action:"status",message:e?.completed?e.reason:a?"\u5FEB\u8FDB\u6267\u884C\u4E2D":"\u5F53\u524D\u9875\u9762\u672A\u5728\u6267\u884C\u5FEB\u8FDB",pageUrl:location.href,completed:!!e?.completed,completionReason:e?.reason,video:D(document.querySelector("video"))}}function f(){if(u.__hnGanbuVideoFastForwardOriginalAddEventListener)return;const e=EventTarget.prototype.addEventListener;u.__hnGanbuVideoFastForwardOriginalAddEventListener=e,EventTarget.prototype.addEventListener=function(b,n,o){if(b!=="timeupdate"||!n){e.call(this,b,n,o);return}const i=function(g){const v=g.target,y=v instanceof HTMLVideoElement?v:null,U=y?Object.getOwnPropertyDescriptor(y,"currentTime"):void 0;let q=!1;if(y&&Number.isFinite(y.duration)&&y.duration>0)try{Object.defineProperty(y,"currentTime",{configurable:!0,get:()=>Math.max(0,y.duration-s.endOffsetSeconds)}),q=!0}catch{}try{if(typeof n=="function"){n.call(this,g);return}n.handleEvent(g)}finally{if(y&&q)try{U?Object.defineProperty(y,"currentTime",U):delete y.currentTime}catch{}}};e.call(this,b,i,o)}}function h(){const e=u.__hnGanbuVideoFastForwardOriginalAddEventListener;e&&(EventTarget.prototype.addEventListener=e,delete u.__hnGanbuVideoFastForwardOriginalAddEventListener)}function E(){if(u.__hnGanbuVideoFastForwardNetworkPatch)return;const e=window.fetch?.bind(window),a=XMLHttpRequest.prototype.open,b=XMLHttpRequest.prototype.send;u.__hnGanbuVideoFastForwardNetworkPatch={originalFetch:window.fetch,originalXhrOpen:a,originalXhrSend:b},e&&(window.fetch=function(o,i){const C=d(o,i);return e(o,i).then(g=>(k(C.url,C.method)&&g.clone().json().then(v=>S(v)).catch(()=>{}),g))}),XMLHttpRequest.prototype.open=function(o,i,C,g,v){this.__hnGanbuProgressRequest={method:String(o||"GET").toUpperCase(),url:String(i)},a.call(this,o,i,C??!0,g??null,v??null)},XMLHttpRequest.prototype.send=function(o){const i=this.__hnGanbuProgressRequest;i&&k(i.url,i.method)&&this.addEventListener("load",()=>{try{const C=typeof this.response=="string"||!this.response?JSON.parse(this.responseText):this.response;S(C)}catch{}}),b.call(this,o)}}function d(e,a){return e instanceof Request?{method:String(a?.method||e.method||"GET").toUpperCase(),url:e.url}:{method:String(a?.method||"GET").toUpperCase(),url:String(e)}}function k(e,a){return a.toUpperCase()==="POST"&&w(e).includes(c)}function w(e){try{return new URL(e,location.href).href}catch{return e}}function S(e){x(e)&&(u.__hnGanbuVideoFastForwardCompletion={completed:!0,reason:"\u68C0\u6D4B\u5230\u5B66\u4E60\u8FDB\u5EA6\u63A5\u53E3\u8FD4\u56DE\u6210\u529F\uFF0C\u8FDB\u5EA6\u5DF2\u8FBE\u5230 100%",updatedAt:Date.now()},r(),h(),_(),window.dispatchEvent(new CustomEvent("hn-ganbu-fast-forward-completed")))}function x(e){if(!e||typeof e!="object")return!1;const a=e;return Number(a.code)===0&&a.msg==="ok"&&a.data?.content==="\u8BB0\u5F55\u6210\u529F"&&Number(a.data?.browseScore)>=100}function _(){const e=u.__hnGanbuVideoFastForwardNetworkPatch;e&&(e.originalFetch&&(window.fetch=e.originalFetch),XMLHttpRequest.prototype.open=e.originalXhrOpen,XMLHttpRequest.prototype.send=e.originalXhrSend,delete u.__hnGanbuVideoFastForwardNetworkPatch)}function I(e){s.muted&&(e.muted=!0);try{e.playbackRate=s.playbackRate}catch{}B(e),e.play().catch(()=>{}),s.dispatchEnded&&(e.dispatchEvent(new Event("timeupdate",{bubbles:!0})),e.dispatchEvent(new Event("ended",{bubbles:!0}))),s.clickNext&&L()}function B(e){if(!Number.isFinite(e.duration)||e.duration<=0)return;const a=Math.max(0,e.duration-s.endOffsetSeconds);try{e.currentTime=a}catch{}}function L(){const e=[".next-episode",".next-btn",'[class*="next"]','[class*="Next"]','button[aria-label*="\u4E0B\u4E00"]','a[aria-label*="\u4E0B\u4E00"]','button[title*="\u4E0B\u4E00"]','a[title*="\u4E0B\u4E00"]'];for(const n of e){const o=document.querySelector(n);if(o instanceof HTMLElement&&P(o))return o.click(),!0}const b=Array.from(document.querySelectorAll('button, a, [role="button"]')).find(n=>{const o=`${n.textContent??""} ${n.getAttribute("aria-label")??""}`;return/下一|下一个|下一节|下一集/.test(o)&&P(n)});return b?(b.click(),!0):!1}function P(e){const a=window.getComputedStyle(e);return!(e.getAttribute("aria-disabled")==="true"||e.hasAttribute("disabled")||a.pointerEvents==="none")&&a.display!=="none"&&a.visibility!=="hidden"}function D(e){if(e instanceof HTMLVideoElement)return{duration:Number.isFinite(e.duration)?Number(e.duration.toFixed(2)):null,currentTime:Number.isFinite(e.currentTime)?Number(e.currentTime.toFixed(2)):null,playbackRate:Number.isFinite(e.playbackRate)?e.playbackRate:null}}}const $={key_ops:["verify"],ext:!0,kty:"EC",x:"_layTSNVNOl41aJZulJQ5ngqlCDaYdVk3_BHMsA3gXc",y:"DL0OK9h76YRnIsC3gcPIdpxVkexYHCZuQy5VRFRDdZM",crv:"P-256"},X="hnGanbuRedeemCode",N="HNGB.v1";let M=null;async function z(t,u,c=new Date){const s=V(u);if(!s||s==="-")return{ok:!1,status:"missing-user",message:"\u8BF7\u5148\u767B\u5F55\u6D77\u5357\u5E72\u90E8\u7F51\u7EDC\u5B66\u9662\uFF0C\u518D\u6267\u884C\u5FEB\u8FDB\u3002"};const F=t.trim();if(!F)return{ok:!1,status:"missing-code",message:`\u8BF7\u5C06\u7528\u6237 ID\uFF1A${s} \u53D1\u7ED9\u5546\u5BB6\u8D2D\u4E70\u5151\u6362\u7801\u3002`};const m=j(F);if(!m.ok)return m;if(!await K(m.signingText,m.signature))return{ok:!1,status:"invalid-signature",message:"\u5151\u6362\u7801\u7B7E\u540D\u65E0\u6548\uFF0C\u8BF7\u786E\u8BA4\u5151\u6362\u7801\u662F\u5426\u5B8C\u6574\u3002"};const r=m.payload;if(V(r.userId)!==s)return{ok:!1,status:"user-mismatch",message:"\u5151\u6362\u7801\u4E0E\u5F53\u524D\u8D26\u53F7\u4E0D\u5339\u914D\uFF0C\u8BF7\u91CD\u65B0\u8D2D\u4E70\u5151\u6362\u7801\u3002",payload:r};const p=W(r.createdAt),f=Z(r.expiresAt);return!p||!f||p.getTime()>f.getTime()?{ok:!1,status:"invalid-payload",message:"\u5151\u6362\u7801\u65E5\u671F\u65E0\u6548\uFF0C\u8BF7\u8054\u7CFB\u5546\u5BB6\u91CD\u65B0\u751F\u6210\u3002",payload:r}:c.getTime()<p.getTime()?{ok:!1,status:"not-started",message:`\u5151\u6362\u7801\u5C1A\u672A\u751F\u6548\uFF0C\u751F\u6548\u65E5\u671F\u4E3A ${r.createdAt}\u3002`,payload:r}:c.getTime()>f.getTime()?{ok:!1,status:"expired",message:`\u5151\u6362\u7801\u5DF2\u4E8E ${r.expiresAt} \u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8D2D\u4E70\u5151\u6362\u7801\u3002`,payload:r}:{ok:!0,status:"valid",message:`\u5151\u6362\u7801\u6709\u6548\u671F\u81F3 ${r.expiresAt}\u3002`,payload:r}}function j(t){const u=t.trim().split(".");if(u.length!==4||`${u[0]}.${u[1]}`!==N)return{ok:!1,status:"invalid-format",message:"\u5151\u6362\u7801\u683C\u5F0F\u4E0D\u6B63\u786E\uFF0C\u8BF7\u7C98\u8D34\u5B8C\u6574\u5151\u6362\u7801\u3002"};const c=u[2],s=u[3];if(!c||!s)return{ok:!1,status:"invalid-format",message:"\u5151\u6362\u7801\u683C\u5F0F\u4E0D\u5B8C\u6574\uFF0C\u8BF7\u7C98\u8D34\u5B8C\u6574\u5151\u6362\u7801\u3002"};try{const F=JSON.parse(Q(c));return Y(F)?{ok:!0,payload:F,signature:O(s),signingText:`${N}.${c}`}:{ok:!1,status:"invalid-payload",message:"\u5151\u6362\u7801\u5185\u5BB9\u65E0\u6548\uFF0C\u8BF7\u8054\u7CFB\u5546\u5BB6\u91CD\u65B0\u751F\u6210\u3002"}}catch{return{ok:!1,status:"invalid-format",message:"\u5151\u6362\u7801\u89E3\u6790\u5931\u8D25\uFF0C\u8BF7\u7C98\u8D34\u5B8C\u6574\u5151\u6362\u7801\u3002"}}}function Y(t){return t.version===1&&typeof t.userId=="string"&&t.userId.trim().length>0&&A(t.createdAt)&&A(t.expiresAt)&&typeof t.nonce=="string"&&t.nonce.trim().length>=8}function V(t){return t.trim()}async function K(t,u){try{const c=await J(),s=u.buffer.slice(u.byteOffset,u.byteOffset+u.byteLength);return await crypto.subtle.verify({name:"ECDSA",hash:"SHA-256"},c,s,new TextEncoder().encode(t))}catch{return!1}}function J(){return M??=crypto.subtle.importKey("jwk",$,{name:"ECDSA",namedCurve:"P-256"},!1,["verify"]),M}function A(t){return typeof t=="string"&&/^\d{4}-\d{2}-\d{2}$/.test(t)}function W(t){if(!A(t))return null;const u=new Date(`${t}T00:00:00`);return Number.isNaN(u.getTime())?null:u}function Z(t){if(!A(t))return null;const u=new Date(`${t}T23:59:59.999`);return Number.isNaN(u.getTime())?null:u}function Q(t){return new TextDecoder().decode(O(t))}function O(t){const u=t.replace(/-/g,"+").replace(/_/g,"/"),c=u.padEnd(Math.ceil(u.length/4)*4,"="),s=atob(c),F=new Uint8Array(s.length);for(let m=0;m<s.length;m+=1)F[m]=s.charCodeAt(m);return F}function G(){function t(l){const r=document.cookie.split(";");for(const p of r){const f=p.indexOf("=");if(f<0)continue;const h=p.slice(0,f).trim(),E=p.slice(f+1).trim();if(c(h)===l)return c(E)}return""}function u(l){const r=l.replace(/-/g,"+").replace(/_/g,"/"),p=r.padEnd(Math.ceil(r.length/4)*4,"="),f=atob(p),h=Uint8Array.from(f,E=>E.charCodeAt(0));return new TextDecoder().decode(h)}function c(l){try{return decodeURIComponent(l)}catch{return l}}const s=t("token");if(!s)return{ok:!1,message:"\u672A\u5728\u5F53\u524D\u9875\u9762 cookie \u4E2D\u8BFB\u53D6\u5230 token"};const m=s.replace(/^Bearer\s*/i,"").trim().split(".");if(m.length<2)return{ok:!1,message:"token \u683C\u5F0F\u4E0D\u7B26\u5408 JWT \u7ED3\u6784"};try{const l=JSON.parse(u(m[1])),r=l.userid??l.id,p=l.name,f=l.username;return r===void 0&&p===void 0&&f===void 0?{ok:!1,message:"token payload \u4E2D\u672A\u627E\u5230\u7528\u6237\u5B57\u6BB5"}:{ok:!0,message:"\u5DF2\u8BFB\u53D6\u5F53\u524D\u767B\u5F55\u7528\u6237",user:{id:r==null?"-":String(r),name:typeof p=="string"&&p?p:"-",username:typeof f=="string"&&f?f:"-"}}}catch{return{ok:!1,message:"token payload \u89E3\u6790\u5931\u8D25"}}}const ee="https://www.higbwlxy.gov.cn/#/play",H=5e3,te=250,ue="hn-ganbu-open-redeem-popup",ne={matches:["https://www.higbwlxy.gov.cn/*"],runAt:"document_idle",world:"MAIN",main(){const t=window;t.__hnGanbuPlayFastForwardButton?.cleanup?.();const u=document.createElement("div");u.id="hn-ganbu-fast-forward-root",u.style.position="fixed",u.style.right="20px",u.style.bottom="96px",u.style.zIndex="2147483647",u.style.display="none";const c=u.attachShadow({mode:"open"});c.innerHTML=`
      <style>
        :host {
          all: initial;
          font-family: "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Segoe UI", Arial, sans-serif;
        }

        .panel {
          display: grid;
          gap: 8px;
          min-width: 156px;
          padding: 10px;
          border: 1px solid rgba(35, 118, 211, 0.28);
          border-radius: 10px;
          background: rgba(255, 255, 255, 0.96);
          box-shadow: 0 10px 28px rgba(17, 24, 39, 0.18);
          backdrop-filter: blur(8px);
        }

        button {
          min-height: 38px;
          padding: 0 14px;
          border: 0;
          border-radius: 8px;
          color: #fff;
          background: #2376d3;
          font: 700 14px/1.2 "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Segoe UI", Arial, sans-serif;
          cursor: pointer;
          transition: background-color 160ms ease, transform 160ms ease, opacity 160ms ease;
        }

        button:hover:not(:disabled) {
          background: #1b63b4;
        }

        button:active:not(:disabled) {
          transform: translateY(1px);
        }

        button:disabled {
          cursor: wait;
          opacity: 0.72;
        }

        button:focus-visible {
          outline: 2px solid #8bbcf0;
          outline-offset: 2px;
        }

        .assist-row {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto auto;
          gap: 8px;
          align-items: center;
        }

        .status {
          margin: 0;
          color: #40506a;
          font: 12px/1.45 "Microsoft YaHei", "PingFang SC", "Hiragino Sans GB", "Segoe UI", Arial, sans-serif;
          overflow-wrap: anywhere;
        }

        .copy-id-button,
        .redeem-button {
          display: none;
          min-height: 28px;
          padding: 0 10px;
          border: 1px solid #b8c7da;
          color: #2376d3;
          background: #fff;
          font-size: 12px;
          white-space: nowrap;
        }

        .copy-id-button:hover:not(:disabled),
        .redeem-button:hover:not(:disabled) {
          background: #edf5ff;
        }

        .copy-id-button.is-visible,
        .redeem-button.is-visible {
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        @media (prefers-reduced-motion: reduce) {
          button {
            transition: none;
          }
        }
      </style>
      <div class="panel">
        <button type="button">\u6267\u884C\u5FEB\u8FDB</button>
        <div class="assist-row">
          <p class="status">\u70B9\u51FB\u540E\u5148\u6821\u9A8C\u5151\u6362\u7801\uFF0C\u518D\u8FD0\u884C 5 \u79D2\u81EA\u52A8\u505C\u6B62</p>
          <button class="copy-id-button" type="button">\u590D\u5236ID</button>
          <button class="redeem-button" type="button">\u586B\u5199\u5151\u6362\u7801</button>
        </div>
      </div>
    `;const s=c.querySelector("button"),F=c.querySelector(".copy-id-button"),m=c.querySelector(".redeem-button"),l=c.querySelector(".status");if(!(s instanceof HTMLButtonElement)||!(F instanceof HTMLButtonElement)||!(m instanceof HTMLButtonElement)||!(l instanceof HTMLParagraphElement))return;const r=s,p=F,f=m,h=l;let E="";document.documentElement.append(u);const d={root:u,completionCheckTimerId:void 0,countdownTimerId:void 0,stopTimerId:void 0,syncTimerId:void 0,cleanup:void 0};t.__hnGanbuPlayFastForwardButton=d,r.addEventListener("click",()=>{k()}),f.addEventListener("click",()=>{document.dispatchEvent(new CustomEvent(ue))}),p.addEventListener("click",()=>{_()});async function k(){if(d.stopTimerId)return;r.disabled=!0,r.textContent="\u6821\u9A8C\u4E2D",h.textContent="\u6B63\u5728\u6821\u9A8C\u767B\u5F55\u72B6\u6001\u4E0E\u5151\u6362\u7801";const n=await S();if(!n.ok){r.disabled=!1,r.textContent="\u6267\u884C\u5FEB\u8FDB",h.textContent=n.message,E=n.userId??"",x(n.needsRedeemCode);return}E=n.userId??"",x(!1);const o=R(b("run"));if(!o.ok){r.disabled=!1,r.textContent="\u6267\u884C\u5FEB\u8FDB",h.textContent=o.message;return}let i=H/1e3;r.disabled=!0,r.textContent=`\u6267\u884C\u4E2D ${i}s`,h.textContent="\u6B63\u5728\u63A8\u8FDB\u89C6\u9891\u8FDB\u5EA6\uFF0C\u7A0D\u540E\u81EA\u52A8\u505C\u6B62",d.countdownTimerId=window.setInterval(()=>{i-=1,r.textContent=`\u6267\u884C\u4E2D ${Math.max(i,0)}s`},1e3),d.completionCheckTimerId=window.setInterval(()=>{const C=t.__hnGanbuVideoFastForwardCompletion;if(C?.completed){B(C.reason||"\u68C0\u6D4B\u5230\u63A5\u53E3\u8FD4\u56DE\u8FDB\u5EA6 100%\uFF0C\u5DF2\u505C\u6B62");return}L()&&B("\u68C0\u6D4B\u5230\u9875\u9762\u8FDB\u5EA6\u5DF2\u5B8C\u6210\uFF0C\u5DF2\u505C\u6B62")},te),d.stopTimerId=window.setTimeout(()=>{B("\u5DF2\u81EA\u52A8\u505C\u6B62\uFF0C\u53EF\u518D\u6B21\u6267\u884C")},H)}const w=()=>{const n=location.href.startsWith(ee);u.style.display=n?"block":"none",n||B("\u70B9\u51FB\u540E\u5148\u6821\u9A8C\u5151\u6362\u7801\uFF0C\u518D\u8FD0\u884C 5 \u79D2\u81EA\u52A8\u505C\u6B62")};w(),window.addEventListener("hashchange",w),window.addEventListener("popstate",w),d.syncTimerId=window.setInterval(w,1e3),d.cleanup=()=>{window.removeEventListener("hashchange",w),window.removeEventListener("popstate",w),d.syncTimerId&&window.clearInterval(d.syncTimerId),B("\u70B9\u51FB\u540E\u5148\u6821\u9A8C\u5151\u6362\u7801\uFF0C\u518D\u8FD0\u884C 5 \u79D2\u81EA\u52A8\u505C\u6B62"),u.remove()};async function S(){const n=G();if(!n.user)return{ok:!1,message:"\u8BF7\u5148\u767B\u5F55\u6D77\u5357\u5E72\u90E8\u7F51\u7EDC\u5B66\u9662\uFF0C\u518D\u6267\u884C\u5FEB\u8FDB\u3002",needsRedeemCode:!1};const o=window.localStorage.getItem(X)??"",i=await z(o,n.user.id);return{ok:i.ok,message:i.message,needsRedeemCode:!i.ok,userId:n.user.id}}function x(n){p.classList.toggle("is-visible",n),f.classList.toggle("is-visible",n)}async function _(){if(E||(E=G().user?.id??""),!E||E==="-"){h.textContent="\u672A\u8BFB\u53D6\u5230\u53EF\u590D\u5236\u7684\u7528\u6237 ID";return}try{await I(E),h.textContent=`\u5DF2\u590D\u5236\u7528\u6237 ID\uFF1A${E}`}catch{h.textContent="\u590D\u5236\u5931\u8D25\uFF0C\u8BF7\u624B\u52A8\u590D\u5236\u7528\u6237 ID"}}async function I(n){if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(n);return}const o=document.createElement("textarea");o.value=n,o.setAttribute("readonly","true"),o.style.position="fixed",o.style.left="-9999px",document.body.append(o),o.select();try{if(!document.execCommand("copy"))throw new Error("copy failed")}finally{o.remove()}}function B(n){d.completionCheckTimerId&&(window.clearInterval(d.completionCheckTimerId),d.completionCheckTimerId=void 0),d.countdownTimerId&&(window.clearInterval(d.countdownTimerId),d.countdownTimerId=void 0),d.stopTimerId&&(window.clearTimeout(d.stopTimerId),d.stopTimerId=void 0,R(b("stop"))),r.disabled=!1,r.textContent="\u6267\u884C\u5FEB\u8FDB",h.textContent=n,x(!1)}function L(){const n=document.querySelector("video");if(n instanceof HTMLVideoElement&&n.ended)return!0;const o=document.querySelector("progress");if(o instanceof HTMLProgressElement){const g=o.max||1;if(g>0&&o.value/g>=.999)return!0}const i=Array.from(document.querySelectorAll(["[aria-valuenow]","[aria-valuetext]",'[class*="progress"]','[class*="Progress"]','[class*="percent"]','[class*="Percent"]','[class*="complete"]','[class*="Complete"]','[class*="finish"]','[class*="Finish"]','[class*="status"]','[class*="Status"]'].join(","))).filter(g=>a(g));for(const g of i)if(P(g)||D(g.textContent??""))return!0;const C=e(document.body?.innerText??"");return/学习完成|播放完成|课程完成|完成学习|获得学时|(?:学习|播放|课程|进度).{0,8}(?:已完成|100%)|100%\s*(?:已完成|完成|学习|进度)/.test(C)}function P(n){const o=Number.parseFloat(n.getAttribute("aria-valuenow")??""),i=Number.parseFloat(n.getAttribute("aria-valuemax")??"100");return Number.isFinite(o)&&o>=100?!0:Number.isFinite(o)&&Number.isFinite(i)&&i>0?o/i>=.999:D(n.getAttribute("aria-valuetext")??"")}function D(n){const o=e(n);return!o||/未完成|未学完|未播放完成/.test(o)?!1:/100%|已完成|学习完成|播放完成|课程完成|完成学习|获得学时/.test(o)}function e(n){return n.replace(/\s+/g," ").trim()}function a(n){const o=window.getComputedStyle(n),i=n.getBoundingClientRect();return o.display!=="none"&&o.visibility!=="hidden"&&i.width>0&&i.height>0}function b(n){return{mode:n,intervalMs:500,endOffsetSeconds:.5,playbackRate:16,muted:!0,dispatchEnded:!0,clickNext:!0}}}};function se(){}function T(t,...u){}const oe={debug:(...t)=>T(console.debug,...t),log:(...t)=>T(console.log,...t),warn:(...t)=>T(console.warn,...t),error:(...t)=>T(console.error,...t)};return(async()=>{try{return await ne.main()}catch(t){throw oe.error('The content script "higbwlxy-play" crashed on startup!',t),t}})()})();

higbwlxyPlay;